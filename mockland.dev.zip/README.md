# MockLand

This is a repository for [MockLand.dev](https://mockland.dev), a project to help students and others to use sample mock apis to develope their applications.

## Project Board

We have standups and we are defining tasks in this [Board](https://github.com/users/ehsangazar/projects/2/views/1), you can reach out to us and get a ticket or two and make them DONE.

## PersiaJS

You can follow PersiaJS socials and groups.

- [PersiaJS.dev](https://persiajs.dev)
- [Join Telegram](https://t.me/joinchat/BcZHTxkf2MoIC1pHxJ_xSw)

## Authors

- [@ehsangazar](https://www.github.com/ehsangazar)
- [@maralnajafi](https://www.github.com/maralnajafi)
- ...

## Deployment

This repository is linked to fly.io, which will be deployed after each merge to main branch.

## Feedback

If you have any feedback, please reach out to us at me@ehsangazar.com

## License

[MIT](https://choosealicense.com/licenses/mit/)
