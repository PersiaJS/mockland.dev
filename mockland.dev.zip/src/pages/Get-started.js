import Hero from "@/components/Hero/Hero";
import Layout from "@/components/Layout/Layout";

export default function getStarted() {
  return (
    <>
      <Layout isActiveSideBar={true}>
        <Hero />
      </Layout>
    </>
  );
}
