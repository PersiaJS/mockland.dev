import VerifyForm from "@/components/VerifyForm/VerifyForm"

const verify = () => {
  return (
    <VerifyForm />
  )
}

export default verify