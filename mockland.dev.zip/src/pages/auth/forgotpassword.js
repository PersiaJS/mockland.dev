import ForgotPasswordForm from "@/components/ForgotPasswordForm/ForgotPasswordForm";
const ForgotPassword = () => {
  return <ForgotPasswordForm />;
};

export default ForgotPassword;
