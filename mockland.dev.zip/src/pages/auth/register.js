import SignupForm from "../../components/SignupForm/SignupForm";

const Register = () => {
  return <SignupForm />;
};

export default Register;
