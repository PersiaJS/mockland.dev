import ResetPasswordForm from "@/components/ResetPasswordForm/ResetPasswordForm";

const resetpassword = () => {
  return <ResetPasswordForm />;
};

export default resetpassword;
